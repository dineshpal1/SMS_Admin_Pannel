<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassSection extends Model
{
    protected $table="tbl_student_classes";
   // protected $table="tbl_class_sections";
}
