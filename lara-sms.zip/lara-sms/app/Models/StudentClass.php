<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StudentClass extends Model
{
     protected $table="tbl_class_sections";
    //protected $table="tbl_student_classes";
}
