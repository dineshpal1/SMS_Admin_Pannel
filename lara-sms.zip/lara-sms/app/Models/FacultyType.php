<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FacultyType extends Model
{
    protected $table="tbl_faculty_types";
}
