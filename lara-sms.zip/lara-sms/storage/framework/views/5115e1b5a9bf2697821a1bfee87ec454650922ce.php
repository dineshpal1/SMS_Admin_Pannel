<?php $__env->startSection("title","Edit Faculty | Techie Dinesh"); ?>
<?php $__env->startSection("content"); ?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Edit Faculty
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Faculty</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
       
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <?php if(session()->has("message")): ?>
              <div class="alert alert-success">
                <p><?php echo e(session("message")); ?></p>
              </div>
            <?php endif; ?>
             <?php if(count($errors)): ?>
             <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <p><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
               <?php endif; ?>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" id="frm-add-faculty" method="post" action="<?php echo e(route('saveeditfaculty1')); ?>" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="faculty_id" value="<?php echo e($faculty->id); ?>">
              <div class="box-body">

               <div class="form-group">
                  <label for="dd_type">Choose Type</label>
                  <select class="form-control" id="dd_type" name="dd_type">
                    <option value="-1">Select Faculty Type</option>
                    <?php if(count($types) > 0): ?>
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type->id); ?>" <?php if($type->type): ?> selected="selected" <?php endif; ?>><?php echo e($type->type); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </select>

                </div>
                  <div class="form-group">
                  <label for="faculty_name">Faculty Name</label>
                  <input type="text" class="form-control" name="faculty_name" value="<?php echo e($faculty->name); ?>" id="faculty_name" placeholder="Enter Faculty Name">
                </div>

                <div class="form-group">
                  <label for="faculty_emial">Faculty Email</label>
                  <input type="eamil" class="form-control" name="faculty_email" id="faculty_email" placeholder="Enter Faculty email" value="<?php echo e($faculty->email); ?>">
                </div>


                <div class="form-group">
                  <label for="faculty_designation">Faculty Designation</label>
                  <input type="text" class="form-control" name="faculty_designation" id="faculty_designation" placeholder="Enter Faculty Designation" value="<?php echo e($faculty->designation); ?>">
                </div>


              <div class="form-group">
                  <label for="faculty_phone">Faculty Phone</label>
                  <input type="number" class="form-control" name="faculty_phone" id="faculty_phone" placeholder="Enter Faculty Phone" value="<?php echo e($faculty->phone_no); ?>">
                </div>

                <div class="form-group">
                  <label for="dd_gender">Gender</label>
                  <select class="form-control" id="dd_gender" name="dd_gender">
                  <option value="-1">Select Gender</option>
                  <?php if(count($genders)>0): ?>
                  <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($gender->id); ?>" <?php if($gender->type): ?> selected="selected" <?php endif; ?>><?php echo e(ucfirst($gender->type)); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  
                </select>
                </div>
                

               <div class="form-group">
                  <label for="faculty_photo">Profile Photo</label>
                  <input type="file" class="form-control" name="faculty_photo" id="faculty_photo" value="<?php echo e($faculty->profile_photo); ?>" >
                </div>

                 <div class="form-group">
                  <label for="faculty_address">Faculty Address</label>
                 <textarea class="form-control" name="faculty_address" id="faculty_address" placeholder="Enter Address" value="<?php echo e($faculty->address); ?>"></textarea>
                </div>


                <div class="form-group">
                  <label for="dd_status">Status</label>
                  <select class="form-control" id="dd_status" name="dd_status">
                  <option value="1"<?php if($faculty->status): ?>selected="selected" <?php endif; ?>>Active</option>
                  <option value="0"<?php if(!$faculty->status): ?> selected="selected" <?php endif; ?>>Inactive</option>
                  </select>
                  
                </div>
                
                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->

          
        </div>
       
       
        </div>
        <!-- ./col -->
      </section>
      <!-- /.row -->
      <!-- Main row -->
      
  </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make("admin.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara-sms\resources\views/admin/views/edit_faculty1.blade.php ENDPATH**/ ?>