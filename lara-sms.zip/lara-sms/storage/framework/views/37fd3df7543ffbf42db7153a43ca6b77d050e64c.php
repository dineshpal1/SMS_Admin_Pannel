<?php $__env->startSection("title","Admin Login"); ?>

<?php $__env->startSection("content"); ?>
<div class="login-box">
  <div class="login-logo">
    <a href="javascript:void(0)"><b>Admin</b>SMS</a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Login Panel</p>
    
	<?php if(count($errors)>0): ?>
	<div class="alert alert-danger">
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<p><?php echo e($error); ?></p>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
	</div>
	<?php endif; ?>
    <form action="<?php echo e(route('checklogin')); ?>" method="post">
    	<?php echo csrf_field(); ?>
      <div class="form-group has-feedback">
        <input type="email" class="form-control" name="email" placeholder="Email">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" name="password" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

        
  </div>
  <!-- /.login-box-body -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.auth_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara-sms\resources\views/admin/views/login_form.blade.php ENDPATH**/ ?>