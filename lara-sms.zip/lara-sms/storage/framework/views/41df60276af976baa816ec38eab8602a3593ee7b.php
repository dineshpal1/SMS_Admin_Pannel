<?php $__env->startSection("title","Edit Class | Techie Dinesh"); ?>
<?php $__env->startSection("content"); ?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Edit Class
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Class</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
       
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <?php if(session()->has("message")): ?>
              <div class="alert alert-success">
                <p><?php echo e(session("message")); ?></p>
              </div>
              <?php endif; ?>

             <?php if(count($errors)>0): ?>
             <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <p><?php echo e($error); ?></p>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
             <?php endif; ?>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" id="frm-add-class" method="post" action="<?php echo e(route('editsaveclass')); ?>">
              <?php echo csrf_field(); ?>

              <input type="hidden" name="class_id" value="<?php echo e($class_data->id); ?>">
              <div class="box-body">

                <div class="form-group">
                  <label for="class_name">Class Name</label>
                  <input type="text" class="form-control" value="<?php echo e($class_data->name); ?>" name="class_name" id="class_name" placeholder="Enter class Name">
                </div>

                <div class="form-group">
                  <label for="dd_section">Choose Section</label>
                  <select class="form-control" id="dd_section" name="dd_section">
                    <option value=-1>Select Section</option>
                    <?php if(count($sections)>0): ?>
                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($section->id); ?>" <?php if($class_data->class_section_id ==$section->id): ?>selected="selected" <?php endif; ?>><?php echo e($section->section); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </select>
                </div>
                

               <div class="form-group">
                  <label for="seats_available">Seats Available</label>
                  <input type="number" min="1"class="form-control"  value="<?php echo e($class_data->seats_available); ?>"name="seats_available" id="seats_available" placeholder="Enter Seats">
                </div>




                <div class="form-group">
                  <label for="dd_status">Status</label>
                  <select class="form-control" id="dd_status" name="dd_status">
                  <option value="1" <?php if($class_data->status): ?> selected="selected"<?php endif; ?>>Active</option>
                  <option value="0"<?php if(!$class_data->status): ?> selected="selected"<?php endif; ?>>Inactive</option>
                  </select>
                  
                </div>
                
                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->

          
        </div>
       
       
        </div>
        <!-- ./col -->
      </section>
      <!-- /.row -->
      <!-- Main row -->
      
  </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make("admin.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara-sms\resources\views/admin/views/edit_class.blade.php ENDPATH**/ ?>